//v3.01
#pragma once 
#ifndef PCH_HPP
#define PCH_HPP

#define OPENCV // using for yolo_class.hpp


//cpp basic header file
//#include <filesystem>  //for c++17
//#include <experimental/filesystem>  //for c++14

#include <sys/stat.h>
#include <unistd.h>

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <queue>
#include <cmath>
#include <thread>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <cstring>     // using for KCF tracker
#include <exception>
#include <math.h> // for calculate detection anlge control
#include <condition_variable>


#include "yolo_class.hpp" //need to include it 
//#include "/home/nvidia/robomaster_extra/darknet/include/yolo_v2_class.hpp"

#ifdef VIRTUAL
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#endif



//deeplearning and opencv basic header file (opencv version 3.4.5)
#include <opencv2/opencv.hpp>
#include <opencv2/core/version.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>

#ifdef MAKEING_IMG
#include <opencv2/videoio/videoio.hpp>
#endif //!MAKEING_IMG

#ifndef VIRTUAL
#include <opencv2/tracking.hpp>  //need to install opencv_contrib 
#include <opencv2/core/ocl.hpp>
#endif

//realsense header file
#include <librealsense2/rs.hpp>
#include <librealsense2/rsutil.h>

//creat datatype red_bluesum (to return redsum, bluesum)
typedef struct{
    float redsum;
    float bluesum;
}red_bluesum;

/* static value managemnet*/


const float PI = 3.141592;

const float confThreshold = 0.3; // Confidence threshold
const float nmsThreshold = 0.4;  // Non-maximum suppression threshold
const int inpWidth = 416;  // Width of network's input image
const int inpHeight = 416; // Height of network's input image


const unsigned int robot_id = 0;
const unsigned int Number1 = 1;
const unsigned int Number2 = 2;
const unsigned int Number1_old = 3;
const unsigned int Number2_old = 4;
const unsigned int wheel = 5;
const unsigned int hp_bar = 6;
// for labeling blue = 0 / red = 1/ dead = 2 


/* 0: blue,
 * 1: red,
 * 2: dead*/
const unsigned int alliance=1;
const unsigned int enemy=2;
const unsigned int dead=3;
#endif

