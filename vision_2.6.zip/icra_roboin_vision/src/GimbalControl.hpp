
//#ifdef ROS
#define SETTING
#include "icra_roboin_msgs/PitchGain.h"
#include "icra_roboin_msgs/YawGain.h"
#include "icra_roboin_msgs/YoloDetectionInfo.h"
#include "roborts_msgs/GimbalAngle.h"
#include "roborts_msgs/ShootCmd.h"
#include "roborts_msgs/FricWhl.h"
// #include "obstacle_detector/Obstacles.h" // TODO check again
#include "ros/ros.h"
//#include "SendData_Control.hpp"
#include "pch.hpp"
#include <cstdio>
#include <math.h>
#include "Data_control.hpp"

#include <fstream>  // https://ra2kstar.tistory.com/147, https://goscala.tistory.com/7
#include <random>  // http://www.cplusplus.com/reference/random/normal_distribution/

//#define X_CENTER_PIXEL 320
//#define Y_CENTER_PIXEL 240

#define X_CENTER_PIXEL 320
#define Y_CENTER_PIXEL 240

#define SEARCH_COUNT 20
#define ONE_EXP_LOOP 200

#ifdef SETTING

#define YPG 0.0007
#define YIG 0.00008
#define YDG 0.0006
#endif

using namespace std;

class GimbalControl {

public:

    ros::Publisher cmd_gimbal_angle_pub;
    ros::ServiceClient cmd_shoot_client;

    ros::ServiceServer yaw_server;
    ros::ServiceServer pitch_server;

    float YAW_P_GAIN;
    float YAW_I_GAIN;
    float YAW_D_GAIN;
    float PITCH_P_GAIN;
    float PITCH_I_GAIN;
    float PITCH_D_GAIN;

    float SEARCH_VEL = 0.08;  // SEARCH_VEL * SEARCH_COUNT = total angle (1.5~1.7)
    bool setCenter = false;
    int search_count = 0;
    short search_dir = 1;
    short lost_count = 0;
    short lidar_detect = 0;
    float out_sight_enemy_angle = 0;


    short yaw_prev_error = 0;
    short pitch_prev_error = 0;
    float yaw_i_error = 0;
    float pitch_i_error = 0;
    roborts_msgs::GimbalAngle gimbal_angle;

    short y_offset = 40;


#ifdef SETTING
    int loop_count = 0;


    float min_p = 0;
    float min_i = 0;
    float min_d = 0;
    unsigned int min_cost = 1000000000;
    unsigned int cost = 0;

    float v_p = 0.00005;
    float v_i = 0.00005;
    float v_d = 0.00005;

    default_random_engine generator;
    float generate_random(float gain, float v);
    /*std::normal_distribution<float> random_yaw_p(float yaw_p_gain, float v);
    std::normal_distribution<float> random_yaw_i(this->YAW_I_GAIN, 0.0001);
    std::normal_distribution<float> random_yaw_d(this->YAW_D_GAIN, 0.0001);*/

    /*
    static bool SetYawGainCallback(icra_roboin_msgs::YawGain::Request &req,
                        icra_roboin_msgs::YawGain::Response &resp);
    static bool SetPitchGainCallback(icra_roboin_msgs::PitchGain::Request &req,
	icra_roboin_msgs::PitchGain::Response &resp);
     */

    void setPIDGain(send_target_info& target);

#endif


public:
    GimbalControl(ros::NodeHandle &nh) {
        this->cmd_gimbal_angle_pub = nh.advertise<roborts_msgs::GimbalAngle>("cmd_gimbal_angle", 1);
        this->cmd_shoot_client =  nh.serviceClient<roborts_msgs::ShootCmd>("cmd_shoot");

        this->YAW_P_GAIN = 0.0007;
        this->YAW_I_GAIN = 0.00008;
        this->YAW_D_GAIN = 0.0006;

        this->PITCH_P_GAIN = 0.0007;
        this->PITCH_I_GAIN = 0.001;
        this->PITCH_D_GAIN = 0.001;
    /*
#ifdef SETTING
        yaw_server = nh.advertiseService("yaw_gain", &GimbalControl::SetYawGainCallback);
        pitch_server = nh.advertiseService("pitch_gain", &GimbalControl::SetPitchGainCallback);
#endif
     */
    }


    void run(send_target_info& target);

private:
    void cmdShoot(int shoot);
};


void GimbalControl::cmdShoot(int shoot) { // 1: shoot, 0: stop
    roborts_msgs::ShootCmd shoot_cmd;
    shoot_cmd.request.mode = shoot;
    shoot_cmd.request.number = shoot;

    if (cmd_shoot_client.call(shoot_cmd)) {
        ROS_INFO("shoot Call Success");
        if(shoot_cmd.response.received == true){
            ROS_INFO("shoot call Received");
        } else {
            ROS_WARN("shoot call Not Received");
        }
    } else {
        ROS_ERROR("shoot Call Fail");
    }
}


#ifdef SETTING
void GimbalControl::setPIDGain(send_target_info& target) {

    if(loop_count == 0) {
        YAW_P_GAIN = generate_random(YPG, v_p);
        while(YAW_P_GAIN < 0) YAW_P_GAIN = generate_random(YPG, v_p);

        YAW_I_GAIN = generate_random(YIG, v_i);
        while(YAW_I_GAIN < 0) YAW_I_GAIN = generate_random(YIG, v_i);

        YAW_D_GAIN = generate_random(YDG, v_d);
        while(YAW_D_GAIN < 0) YAW_D_GAIN = generate_random(YDG, v_d);

        printf("Trying New Gains P: %f, I: %f, D: %f\n", YAW_P_GAIN, YAW_I_GAIN, YAW_D_GAIN);
    }
	
	if (target.infochecker > 0) {
            //printf("pixel control start\n");
//		Sendinfo target = gimbal;

            // ROS_ERROR("armor pixel: %d, %d\n", target.Pixel_X, target.Pixel_Y);
            short pixel_error_x = target.Pixel_X - X_CENTER_PIXEL;
            short pixel_error_y = target.Pixel_Y - Y_CENTER_PIXEL - 12;

            cost += pixel_error_x;

            yaw_i_error += pixel_error_x;
            pitch_i_error += pixel_error_y ;

            // pid
            float angle_cmd = -pixel_error_x * YAW_P_GAIN - yaw_i_error * YAW_I_GAIN + (yaw_prev_error - pixel_error_x) * YAW_D_GAIN;
            gimbal_angle.yaw_angle = angle_cmd;

            //printf("error: %d d_error: %d cmd_angle: %f\n", pixel_error_x, yaw_prev_error - pixel_error_x, angle_cmd);
            //    gimbal_angle.pitch_angle = pixel_error_y * PITCH_P_GAIN + pitch_i_error * PITCH_I_GAIN + (pitch_prev_error- pixel_error_y) * PITCH_D_GAIN;
            if (angle_cmd > 3) angle_cmd = 3;
            else if (angle_cmd < -3) angle_cmd = -3;
            gimbal_angle.yaw_angle = angle_cmd;

            //    gimbal_angle.yaw_angle = -pixel_error_x * YAW_P_GAIN;
            gimbal_angle.pitch_angle = pixel_error_y * PITCH_P_GAIN;
            gimbal_angle.yaw_mode = true;
            gimbal_angle.pitch_mode = true;

            cmd_gimbal_angle_pub.publish(gimbal_angle);

            yaw_prev_error = pixel_error_x;
            pitch_prev_error = pixel_error_y;


            lost_count = 0;
            loop_count++;
	} else {
            lost_count++;
            if(lost_count > 100) {
                    lost_count = 0;
                    loop_count = 0;
            }
            if(lost_count > 10) {
                printf("lost detection. reset prev_error\n");
        //lost_count = 11;

                yaw_i_error = 0;
                pitch_i_error = 0;
                yaw_prev_error = 0;
                pitch_prev_error = 0;

            }
	}

	if(loop_count >= ONE_EXP_LOOP) {
	    if(cost < min_cost) {
	        min_p = YAW_P_GAIN;
	        min_i = YAW_I_GAIN;
	        min_d = YAW_D_GAIN;
	        min_cost = cost;
	    }
	    printf("Min Gains So Far  P: %f, I: %f, D: %f, min_cost: %d\n", min_p, min_i, min_d, min_cost);

	    ofstream outputStream;
	    outputStream.open("/home/nvidia/roboinTX2/src/icra_roboin_vision/output.csv", fstream::out | fstream::app);
	    outputStream << YAW_P_GAIN << "," << YAW_I_GAIN << "," << YAW_D_GAIN << "," << cost << endl;
	    outputStream.close();

	    cost = 0;
	    loop_count = 0;

	}
}

/*
bool GimbalControl::SetYawGainCallback(icra_roboin_msgs::YawGain::Request &req,
                        icra_roboin_msgs::YawGain::Response &resp) {
    if (req.p != 0.0) YAW_P_GAIN = req.p;
    if (req.i != 0.0) YAW_I_GAIN = req.i;
    if (req.d != 0.0) YAW_D_GAIN = req.d;
    //("yaw pid: %f %f %f\n", this->YAW_P_GAIN, this->YAW_I_GAIN, this->YAW_D_GAIN);
    yaw_prev_error = 0;
    pitch_prev_error = 0;
    yaw_i_error = 0;
    pitch_i_error = 0;

    resp.received = true;
    return true;
}

bool GimbalControl::SetPitchGainCallback(icra_roboin_msgs::PitchGain::Request &req,
	icra_roboin_msgs::PitchGain::Response &resp) {

	if (req.p != 0.0) this->PITCH_P_GAIN = req.p;
	if (req.i != 0.0) this->PITCH_I_GAIN = req.i;
	if (req.d != 0.0) this->PITCH_D_GAIN = req.d;
	printf("pitch pid: %f %f %f\n", this->PITCH_P_GAIN, this->PITCH_I_GAIN, this->PITCH_D_GAIN);
	yaw_prev_error = 0;
	pitch_prev_error = 0;
	yaw_i_error = 0;
	pitch_i_error = 0;

	resp.received = true;
	return true;
}

 */

#endif

#ifdef SETTING
    float GimbalControl::generate_random(float gain, float v) {

        std::normal_distribution<float> random_generator(gain, v);
        return random_generator(this->generator);
}

#endif

void GimbalControl::run(send_target_info& target) {
#ifdef SETTING
    GimbalControl::setPIDGain(target);
    return;
#endif

    //printf("pixel control ready\n");

	if (target.infochecker > 0) {
		printf("pixel control start\n");
//		Sendinfo target = gimbal;

		ROS_ERROR("armor pixel: %d, %d\n", target.Pixel_X, target.Pixel_Y);
		short pixel_error_x = target.Pixel_X - X_CENTER_PIXEL;
		short pixel_error_y = target.Pixel_Y - Y_CENTER_PIXEL - 12;

		if(pixel_error_x < 10 && pixel_error_x > -10){
         //printf("shoot!!!!\n");
		  cmdShoot(1);
		} else {
		  cmdShoot(0);
         //printf("no shoot!!!!\n");
		}

		// std::cout <<"target: " <<target.assinged_number<<std::endl;

        this->yaw_i_error += pixel_error_x;
        this->pitch_i_error += pixel_error_y ;

		// pid
		float angle_cmd = -pixel_error_x * this->YAW_P_GAIN - yaw_i_error * this->YAW_I_GAIN + (this->yaw_prev_error - pixel_error_x) * this->YAW_D_GAIN;
        this->gimbal_angle.yaw_angle = angle_cmd;

		//printf("error: %d d_error: %d cmd_angle: %f\n", pixel_error_x, this->yaw_prev_error - pixel_error_x, angle_cmd);
		//    gimbal_angle.pitch_angle = pixel_error_y * PITCH_P_GAIN + pitch_i_error * PITCH_I_GAIN + (pitch_prev_error- pixel_error_y) * PITCH_D_GAIN;
		if (angle_cmd > 3) angle_cmd = 3;
		else if (angle_cmd < -3) angle_cmd = -3;
        this->gimbal_angle.yaw_angle = angle_cmd;


		//    gimbal_angle.yaw_angle = -pixel_error_x * YAW_P_GAIN;
        this->gimbal_angle.pitch_angle = pixel_error_y * this->PITCH_P_GAIN;

        this->gimbal_angle.yaw_mode = true;
        this->gimbal_angle.pitch_mode = true;

        this->cmd_gimbal_angle_pub.publish(gimbal_angle);

        this->yaw_prev_error = pixel_error_x;
        this->pitch_prev_error =pixel_error_y;


        lost_count = 0;
	    setCenter = false;
	} else {

		cmdShoot(0);

        this->lost_count++;
		if(this->lost_count > 10) {
		    printf("lost detection. reset prev_error\n");
            this->lost_count = 11;

            this->yaw_i_error = 0;
            this->pitch_i_error = 0;
            this->yaw_prev_error = 0;
            this->pitch_prev_error = 0;

            if(this->lidar_detect > 0) {
                this->gimbal_angle.pitch_mode = true; // not needed
                this->gimbal_angle.yaw_mode = false;

                this->gimbal_angle.yaw_angle = out_sight_enemy_angle;
                this->cmd_gimbal_angle_pub.publish(gimbal_angle);
            }
		}

    }






        // search left <-> right
	/*	lost_count++;
		if(lost_count > 10) {
		if(!setCenter)  {
			gimbal_angle.pitch_mode = false;
			gimbal_angle.yaw_mode = false;
			gimbal_angle.yaw_angle = 0;
			cmd_gimbal_angle_pub.publish(gimbal_angle);
			setCenter = true;
		} else {
			gimbal_angle.pitch_mode = false;
	            gimbal_angle.yaw_mode = true;
            		gimbal_angle.yaw_angle = SEARCH_VEL * search_dir;
	            cmd_gimbal_angle_pub.publish(gimbal_angle);
}

            if (search_count == SEARCH_COUNT) {
                search_dir *= -1;
                search_count = 0;
            }
            search_count++;
		}
	}
	 */
}


//#endif

