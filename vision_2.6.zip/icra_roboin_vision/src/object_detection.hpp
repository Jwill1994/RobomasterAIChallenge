//V3.01
#pragma once
#ifndef OBJECT_DETECTION_HPP
#define OBJECT_DETECTION_HPP


#include "pch.hpp"
#include "yolo_class.hpp"
//#include "/home/nvidia/robomaster_extra/darknet/include/yolo_v2_class.hpp"
#include "Data_control.hpp"
#include "camera.hpp"


using namespace darknet;

/*this is bridge of yolo and Data_control*/
class vision_detector {
public:

    std::vector<bbox_t> detect_Data;
    std::vector<std::string> obj_names;

	/*Original Network*/
//	std::string  names_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolo3.names";
//	std::string  cfg_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolov3.cfg";
//	std::string  weights_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolov3-tiny.backup";

    /*Yolo v3-tiny 3classes*/
//	std::string  names_file = "/home/nvidia/weights/yolov3-tiny_3c/obj.names";
//	std::string  cfg_file = "/home/nvidia/weights/yolov3-tiny_3c/yolov3-tiny_420_224.cfg";
//	std::string  weights_file = "/home/nvidia/weights/yolov3-tiny_3c/obj.names";

	/*Yolo v2 3classes*/
	std::string weights_file= "/home/nvidia/weights/yolov2/yolov2.backup";
	std::string names_file = "/home/nvidia/weights/yolov2/obj.names";
	std::string cfg_file="/home/nvidia/weights/yolov2/yolov2_test.cfg";

private:
	

	/*filename maker*/
	std::vector<std::string> objects_names_from_file(std::string const filename);
        /*red blue sum calculation*/
        red_bluesum redbluesum(cv::Mat input_img, int x, int y, int w, int h);

	/*drawing box*/
        cv::Mat draw_boxes(cv::Mat mat_img, cv::Mat dept_img, std::vector<bbox_t> result_vec, std::vector<std::string> obj_names,int current_det_fps, int current_cap_fps);

	/*detecting*/
	void CUDA_Detect_VisionDataet(std::vector<bbox_t> detect_Data, VisionDataset& dataset);

public:

	/*detector initialize*/
	vision_detector(Detector& detector) {
		
#ifndef VIRTUAL
		//this->names_file = "/home/nvidia/CLionProjects/vision_dev/yolo/yolo3.names";// class file path (name of objects)
		//this->cfg_file = "/home/nvidia/CLionProjects/vision_dev/yolo/yolov3.cfg";  //cfg File and weights File path setting
		//this->weights_file = "/home/nvidia/CLionProjects/vision_dev/yolo/yolov3-tiny.backup";

		detector.nms = nmsThreshold;
		this->obj_names = this->objects_names_from_file(this->names_file);

#ifdef DISPLAY
		cv::namedWindow("Display window", cv::WINDOW_AUTOSIZE);
#endif
		
#else
		//GZbot code insert (GZbot yolo wighte file pate is needed)
		this->names_file = "/home/nvidia/CLionProjects/vision_dev/yolo/yolo3.names";// class file path (name of objects)
		this->cfg_file = "/home/nvidia/CLionProjects/vision_dev/yolo/yolov3.cfg";  //cfg File and weights File path setting
		this->weights_file = "/home/nvidia/weights/420_224_model_with_420_224_image/yolov3-tiny_420_224.backup";
		this->detector(this->cfg_file, this->weights_file);
		this->detector.nms = nmsThreshold;
		this->obj_names = this->objects_names_from_file(this->names_file);
#endif //!VIRTUAL
#ifdef DEBUG
		std::cout << "vision_detector initialized" << std::endl;
#endif
	}

	~vision_detector() = default;
	
	void vision_detector_run(vision_camera& camera,data_control& CT_data, Detector& detector);

};

std::vector<std::string> vision_detector::objects_names_from_file(std::string const filename) {
    std::ifstream file(filename);
    std::vector<std::string> file_lines;
    if (!file.is_open()) return file_lines;
    for (std::string line; getline(file, line);) file_lines.push_back(line);
#ifdef DEBUG
    std::cout << "object names loaded \n";
#endif
    return file_lines;
}

red_bluesum vision_detector::redbluesum(cv::Mat input_img, int x, int y, int w, int h){
    red_bluesum result;

    cv::Rect region_of_interest = cv::Rect(x,y,w,h);
    std::cout << region_of_interest << std::endl;
    cv::Mat image_roi = input_img(region_of_interest);
    cv::Mat hsv;
    cvtColor(image_roi, hsv, CV_BGR2HSV);
    cv::Mat blue;
    cv::Mat red1;
    cv::Mat red2;
    cv::Mat red;
    //extract red pixel
    cv::inRange(hsv, cv::Scalar(0, 100, 100,0), cv::Scalar(10, 255, 255,0), red1);
    cv::inRange(hsv, cv::Scalar(160, 100, 100,0), cv::Scalar(179, 255, 255,0), red2);
    red=red1 | red2;
    //extract blue pixel
    cv::inRange(hsv, cv::Scalar(110,150,150,0),cv::Scalar(130,255,255,0),blue);

    result.bluesum=cv::sum(blue)[0];
    result.redsum=cv::sum(red)[0];

    return result;
}

cv::Mat vision_detector::draw_boxes(cv::Mat mat_img, cv::Mat dept_img, std::vector<bbox_t> result_vec, std::vector<std::string> obj_names,int current_det_fps = -1, int current_cap_fps = -1)
{
    int const colors[6][3] = { { 1,0,1 },{ 0,0,1 },{ 0,1,1 },{ 0,1,0 },{ 1,1,0 },{ 1,0,0 } };
    cv::Mat boxed_img;
    boxed_img= mat_img.clone();
    for (auto &i : result_vec) {
        cv::Scalar color = darknet:: obj_id_to_color(i.obj_id);
        cv::rectangle(boxed_img, cv::Rect(i.x, i.y, i.w, i.h), color, 2);
        cv::rectangle(dept_img, cv::Rect(i.x,i.y,i.w,i.h),0,2);
        if (obj_names.size() > i.obj_id) {
            std::string obj_name = obj_names[i.obj_id];
            if (i.track_id > 0) obj_name += " - " + std::to_string(i.track_id);
            cv::Size const text_size = getTextSize(obj_name, cv::FONT_HERSHEY_COMPLEX_SMALL, 1.2, 2, 0);
            int const max_width = (text_size.width > i.w + 2) ? text_size.width : (i.w + 2);
            if(obj_name=="robot") {

                red_bluesum result=this->redbluesum(mat_img,i.x,(int)(i.y+i.h/2),
                                                    std::min(i.w,mat_img.cols-i.x-1),
                                                    (int)(std::min(i.h/2,mat_img.cols-i.y-i.h/2-1)));
                float sumblue=result.bluesum;
                float sumred=result.redsum;
                std::cout<<"sumblue/sumred: " << (sumblue+1)/(sumred+1) <<
                            " sumblue: "<<sumblue<<
                           " sumred: " <<sumred<<
                           std::endl;
                if(((sumblue+10000)/(sumred+10000)<2 && (sumblue+10000)/(sumred+10000)>0.5)||sumred==sumblue){
                    obj_name="dead";
                }
                else if (sumblue > sumred) {
                    obj_name = "blue";
                }
                else if (sumblue < sumred) {
                    obj_name = "red";
                }

            }
            if(obj_name=="number1" or obj_name=="number2"){
                red_bluesum result=this->redbluesum(mat_img,i.x,i.y,
                                                    std::min(i.w,mat_img.cols-i.x-1),
                                                    std::min(i.h,mat_img.cols-i.y-i.h-1));
                float sumblue=result.bluesum;
                float sumred=result.redsum;
                std::cout<<"sumblue/sumred: " << (sumblue+1)/(sumred+1) <<
                            " sumblue: "<<sumblue<<
                           " sumred: " <<sumred<<
                           std::endl;
                if(obj_name=="number1"){
                    if(((sumblue+1000)/(sumred+1000)<2 && (sumblue+1000)/(sumred+1000)>0.5)||sumred==sumblue){
                        obj_name="#1_dead";
                    }
                    else if (sumblue > sumred) {
                        obj_name = "#1_blue";
                    }
                    else if (sumblue < sumred) {
                        obj_name = "#1_red";
                    }
                }
                if(obj_name=="number2"){
                    if(((sumblue+1000)/(sumred+1000)<2 && (sumblue+1000)/(sumred+1000)>0.5)||sumred==sumblue){
                        obj_name="#2_dead";
                    }
                    else if (sumblue > sumred) {
                        obj_name = "#2_blue";
                    }
                    else if (sumblue < sumred) {
                        obj_name = "#2_red";
                    }
                }

            }
            cv::rectangle(boxed_img, cv::Point2f(std::max((int)i.x - 1, 0), std::max((int)i.y - 30, 0)),
                          cv::Point2f(std::min((int)i.x + max_width, boxed_img.cols - 1), std::min((int)i.y, boxed_img.rows - 1)),
                          color, CV_FILLED, 8, 0);
            putText(boxed_img, obj_name, cv::Point2f(i.x, i.y - 10), cv::FONT_HERSHEY_COMPLEX_SMALL, 1.2, cv::Scalar(0, 0, 0), 2);
        }
    }
    if (current_det_fps >= 0 && current_cap_fps >= 0) {
        std::string fps_str = "FPS detection: " + std::to_string(current_det_fps) + "   FPS capture: " + std::to_string(current_cap_fps);
        putText(mat_img, fps_str, cv::Point2f(10, 20), cv::FONT_HERSHEY_COMPLEX_SMALL, 1.2, cv::Scalar(50, 255, 0), 2);
    }
    return boxed_img;
}

void vision_detector::CUDA_Detect_VisionDataet(std::vector<bbox_t> detect_Data, VisionDataset& dataset) {
    int detection_num = 0;
    for (auto &i : detect_Data) {
        //cv::Scalar color = obj_id_to_color(i.obj_id);
        //cv::rectangle(mat_img, cv::Rect(i.x, i.y, i.w, i.h), color, 2);  // doesn`t used
        if (i.prob > confThreshold) {
            if (i.obj_id == robot_id) {
                if (detection_num < 6) {
                    dataset.height[detection_num] = i.h;
                    dataset.width[detection_num] = i.w;
                    dataset.Center_X[detection_num] = i.x + 0.5 * (i.w);
                    dataset.Center_Y[detection_num] = i.y + 0.5 * (i.h);
                    dataset.prob[detection_num] = i.prob;
                    dataset.robot_id[detection_num] = robot_id; //enemy
                }
                detection_num = detection_num + 1;
            }
        }
    }
    dataset.number_of_detection = detection_num;
}

void vision_detector::vision_detector_run(vision_camera& camera,data_control& CT_data,Detector& detector) {

#ifdef DEBUG
	std::cout << " vision_detector_start " << std::endl;
#endif //!DEBUG
    CT_data.runing_initialize(); //clear data before running
#ifdef DEBUG
	std::cout << " initialize finish " << std::endl;
#endif //!DEBUG
    this->detect_Data = detector.detect(CT_data.dataset.detectimg , 0.3, false);
#ifdef DEBUG
	std::cout << " detection finish " << std::endl;
#endif //!DEBUG
#ifdef DISPLAY
#endif //!DISPLAY

    this->CUDA_Detect_VisionDataet(this->detect_Data , CT_data.dataset); // input detection data
    CT_data.VisionDataset_KCFCORMaker();  //left top X and Y coordinate maker
    CT_data.armour_assign(this->detect_Data); //assign armour to each robot;
    //camera.VisionDataset_getDepth(CT_data);  //insert distance of each robot

#ifdef DISPLAY
    int start_x=50;
    int start_y=32;
    cv::Mat dept=CT_data.dataset.depth_img(cv::Rect(start_x,start_y,423-start_x-75,239-start_y-37));
    cv::resize(dept,dept,cv::Size(424,240));

    cv::Mat boxed_img=this->draw_boxes(CT_data.dataset.display, dept, this->detect_Data, this->obj_names);  //for display drowing boxed
    cv::imshow("Display window" , boxed_img);
    cv::imshow("Depth window", dept.clone());
#endif //!DISPLAY


#ifdef DEBUG
	std::cout << " (vision_detector::vision_detector_run) vision_detector_run is worked " << std::endl;
#endif //!DEBUG

}


#endif


