#ifndef ALL_HPP
#define ALL_HPP

#include "pch.hpp"
#include "Data_control.hpp"
#include "yolo_class.hpp"
//#include "/home/nvidia/robomaster_extra/darknet/include/yolo_v2_class.hpp"
#include "camera.hpp"
#include "object_detection.hpp"
#include "Vision_ros.hpp"
#include "GimbalControl.hpp"


#endif // !ALL_HPP

