//v3.01
#pragma once
#ifndef DATA_CONTROL_HPP
#define DATA_CONTROL_HPP

#include "pch.hpp"

/*armour data*/
struct armour_data {   //need to change
	// if you learning, you should do max labeling obliqued label
	short dominant_armour = 0;
	short number_of_armer = 0;
	short armour_type[6] = { 0, 0, 0, 0, 0, 0 };
	double armour_confidence[6] = { 0, 0, 0, 0, 0, 0 };
	short Center_x[6] = { 0, 0, 0, 0, 0, 0 };
	short Center_y[6] = { 0, 0, 0, 0, 0, 0 };
	short width[6] = { 0, 0, 0, 0, 0, 0 };
	short height[6] = { 0, 0, 0, 0, 0, 0 };
	double distance[6] = { 0, 0, 0, 0, 0, 0 };
};
/*for inner controling*/
struct VisionDataset {

	bool Detection;

	cv::Mat detectimg;  //opencv color img 
	cv::Mat afterimg;
	cv::Mat depth_img;  //for distance data 
#ifdef DISPLAY
	cv::Mat display;
#endif
	short number_of_detection = 0;
	short how_old = 0;

	short robot_id[6] = { 0,0,0,0,0,0 };  //red or blue or die data will give  0= no_data , 1 = allay , 2= enemy , 3=dead
	double prob[6] = { 0, 0, 0, 0, 0, 0 };

	short Center_X[6] = { 0,0,0,0,0,0 };  // this dataset can store maximun 3 robot
	short Center_Y[6] = { 0,0,0,0,0,0 };
	double height[6] = { 0,0,0,0,0,0 };
	double width[6] = { 0,0,0,0,0,0 };
	double KCF_X[6] = { 0,0,0,0,0,0 };  //left top x 
	double KCF_Y[6] = { 0,0,0,0,0,0 };  //left top y
	double distance[6] = { 0,0,0,0,0,0 };
	
	armour_data armour[6];


	double KCF_X_old[6] = { 0,0,0,0,0,0 };
	double KCF_Y_old[6] = { 0,0,0,0,0,0 };
	short trakcer_data[6] = { 4,4,4,4,4,4 };

};
/*robot info*/
struct Send_robot_info {  //gimbal.Pixel_X

	short type_of_robot = 0 ; // 0 > no data, 1 > allay , 2 > enemy , 3> dead

	short angle_hori = 0;   // based on center line left is minus, righet is pluse
	short angle_verti = 0;   // based on center line upper is plus lower is minus  
	short Pixel_X = 0;  //center_X
	short Pixel_Y = 0;  //center_Y
	short Pixel_width = 0;     //pixel coordinate`s width 
	short Pixel_height = 0;    //pixel coordinate`s height
	float distance = 0;  //it is based on meter 

	//v3.01 >> change type
	short assigned_number = 0;  //dominent number of armour

	short numbers_of_armour = 0; // total detected number of armour
	short assinged_armour_number[6];  //all armour data of robot
	float prob_of_armour[6]; // probability of each armour

	float prob_of_robot;
};
/*this struct for gimbal*/
struct send_target_info {

	short infochecker = 0 ;  //if 0: no data, 1: target, 2: area of interest

	short Pixel_X = 0;
	short Pixel_Y = 0;
	float distance = 0;

};
/*dataset for send to Black_board*/
struct sendDataset {

	short number_of_detection = 0;
	Send_robot_info send_robot_info[6]; //v3.01 >> change from send_info to send_robot 

};
/***************************************************************************************************************/
/*this class for vision data control (all data is in it)*/
class data_control {
public:
    	VisionDataset dataset;
	bool First_tracking = true;
private:
	void armour_initialize(armour_data& armour);
	void VisionDataset_initialize(VisionDataset& dataset);
	bool VisionDataset_checker(int numberofdetection);
	float VisionDataset_avoid_zero(short x, short y);
	
	

public:
	
	/*data_control initialize*/
	data_control(){
		this->VisionDataset_initialize(this->dataset);

#ifdef DEBUG
		std::cout << "data_control initialized" << std::endl;
#endif //!DEBUG
	}
	~data_control() = default;

	/*clear the data set before detecting*/
	void runing_initialize();
	/*for tracking but doesn`t needed*/
	void VisionDataset_continueTraking();
	/*for making left top x and y corrdinate*/
	void VisionDataset_KCFCORMaker();
	/*for assign armour each robot*/
	void armour_assign(std::vector<bbox_t> detect_Data);
	/*use CV Mat for get depth data*/
	float linial_align(short RGB_X, short RGB_Y);
};
/*prepare for send mssage*/
class send_control {
public:
	sendDataset to_black_board;
	send_target_info to_gimbal;

private:
	void Send_robot_info_clear(Send_robot_info& robot);
	void to_gimbal_clear();
	void to_black_board_clear();
	/*clear the inner data*/
	void send_data_clear();
	/*for angle maker, it is for upload black board*/
	void angle_maker(short& hori, short& verti, data_control& CT_data, int i);
	/*for black board data maker*/
	void send_black_board_maker(data_control& CT_data);
	/*for select target data*/
	void send_gimbal_maker(data_control& CT_data);
	send_target_info find_target(data_control& CT_data);


public:
	send_control() {
		this->send_data_clear();

#ifdef DEBUG
		std::cout << " (send_control::) send_control is initialized " << std::endl;
#endif //!DEBUG
	}
	~send_control() = default;

	/*for total send_data_maker*/
	void send_data_maker(data_control& CT_data);
};
#ifdef VIRTUAL
class ImageConverter

{
private:

	image_transport::ImageTransport it_;
	image_transport::Subscriber image_sub_;
	cv_bridge::CvImagePtr cv_ptr_;
	bool is_new_img_;

public:
	ImageConverter(ros::NodeHandle nh) : it_(nh) {
		image_sub_ = it_.subscribe("simulated_image_topic", 1, &ImageConverter::imageCB, this);
	}
	~ImageConverter() = default;
	void imageCB(const sensor_msgs::ImageConstPtr& msg) {
		try {
			cv_ptr_ = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
			is_new_img_ = true;
		}
		catch (cv_bridge::Exception& e) {
			ROS_ERROR("cv_bridge exception: %s", e.what());
			return;
		}
	}
	cv::Mat GetImage() {
		while (is_new_img_);
		is_new_img_ = false;
		return cv_ptr_->image;
	}
};



class DepthConverter

{
private:

	image_transport::ImageTransport it_;

	image_transport::Subscriber image_sub_;

	cv_bridge::CvImagePtr cv_ptr_;
	bool is_new_img_;

public:

	DepthConverter(ros::NodeHandle nh) : it_(nh) {
		image_sub_ = it_.subscribe("simulated_depth_image_topic", 1, &DepthConverter::imageCB, this);
	}
	~DepthConverter() = default;

	void imageCB(const sensor_msgs::ImageConstPtr& msg) {
		try {
			cv_ptr_ = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_16UC1);
			is_new_img_ = true;
		}
		catch (cv_bridge::Exception& e) {
			ROS_ERROR("cv_bridge exception: %s", e.what());
			return;
		}
	}
	cv::Mat GetDepth() {
		while (is_new_img_);
		is_new_img_ = false;
		return cv_ptr_->image;
	}
	int getDepthdata(short x, short y) {
		return cv_ptr_->image.at<shrot int>(cv::Point(x, y));
	}

};

static float SIMUL
#endif //!VIRTUAL
/***************************************************************************************************************/
void data_control::armour_initialize(armour_data& armour) {
    armour.number_of_armer = 0;
    int index = 0;
    for (index = 0; index < 6; index++) {
        armour.armour_type[index] = 0;
        armour.armour_confidence[index] = 0;
        armour.Center_x[index] = 0;
        armour.Center_y[index] = 0;
        armour.width[index] = 0;
        armour.height[index] = 0;
        armour.distance[index] = 0;
        armour.dominant_armour = 0;
    }
}
void data_control::VisionDataset_initialize(VisionDataset& dataset) {
    //delete detection information from frame

    dataset.number_of_detection = 0;

    for (int index = 0; index < 6; index++) {

        dataset.Center_X[index] = 0;
        dataset.Center_Y[index] = 0;
        dataset.height[index] = 0;
        dataset.width[index] = 0;
        dataset.KCF_X[index] = 0;
        dataset.KCF_Y[index] = 0;
        dataset.distance[index] = 0;
        dataset.prob[index] = 0;
        dataset.robot_id[index] = 0;

        for (int i = 0; i < 6; i++) {
            this->armour_initialize(dataset.armour[index]);
        }
    }

}
bool data_control::VisionDataset_checker(int numberofdetection) {
    // if there are no detection return true

    if (numberofdetection <= 0)
    {
#ifdef DEBUG
        std::cout << "(VisionDataset_checker)_numberofdetection is zero" << std::endl;
#endif
        return true;
    }

    return false;

}
void data_control::runing_initialize() {
    this->VisionDataset_initialize(this->dataset);
    this->dataset.how_old = 0;
    this->First_tracking = true;
#ifdef DEBUG
	std::cout << "(Class::data_control) runing_initialize is worked " << std::endl;
#endif //!DEBUG
}
void data_control::VisionDataset_continueTraking() {
    this->dataset.detectimg =this->dataset.afterimg;
    // copy new img to old img
#ifdef DEBUG
    std::cout << "(VisionDataset_continueTraking) is worked" << std::endl;
#endif //!DEBUG
}
void data_control::VisionDataset_KCFCORMaker()
{
	

    int index;
    for (index = 0; index < 6; index++) {
        if (this->dataset.Center_X[index] > 0 && this->dataset.Center_Y[index] > 0) {
            this->dataset.KCF_X[index] = (this->dataset.Center_X[index]) - ((this->dataset.width[index]) * 0.5);
            this->dataset.KCF_Y[index] = (this->dataset.Center_Y[index]) - ((this->dataset.height[index]) * 0.5);
        }
    }
#ifdef VISION_DATACHECK
    std::cout << "(VisionDataset_KCFCORMaker)" << "dataset.Center_X[0]:" << this->dataset.Center_X[0] << " dataset.Center_X[1]:" << this->dataset.Center_X[index] << " dataset.Center_X[2]:" << this->dataset.Center_X[2] << std::endl;
	std::cout << "(VisionDataset_KCFCORMaker)" << " dataset.KCF_X[0]:" << this->dataset.KCF_X[0] << " dataset.KCF_X[1]:" << this->dataset.KCF_X[1] << " dataset.KCF_X[2]:" << this->dataset.KCF_X[2] << std::endl;
#endif
}
void data_control::armour_assign(std::vector<bbox_t> detect_Data) {

    short index = 0;

    int number_of_armer = 0;

    for (auto &i : detect_Data) {

        //cv::Scalar color = obj_id_to_color(i.obj_id);

        //cv::rectangle(mat_img, cv::Rect(i.x, i.y, i.w, i.h), color, 2);  // doesn`t used

        if (i.prob > confThreshold && ((i.obj_id == Number1) || (i.obj_id == Number2))) {
            for (index = 0; index < 6; index++) {   //first we check the detected robot data and check only ememy

                if (this->dataset.Center_X[index] > 0 && this->dataset.Center_Y[index] > 0) {  //if there are no data, check next data

                    if (this->dataset.KCF_X[index] < (i.x + 0.5*(i.w)) && this->dataset.KCF_Y[index] < (i.y + 0.5*(i.h)) && (i.x + 0.5*(i.w)) < (this->dataset.KCF_X[index] + this->dataset.width[index]) && (i.y + 0.5*(i.h)) < (this->dataset.KCF_Y[index] + this->dataset.height[index])) {
						this->dataset.armour[index].Center_x[number_of_armer] = i.x + 0.5*(i.w);
						this->dataset.armour[index].Center_y[number_of_armer] = i.y + 0.5*(i.h);
						this->dataset.armour[index].width[number_of_armer] = i.w;
						this->dataset.armour[index].height[number_of_armer] = i.h;
						this->dataset.armour[index].armour_type[number_of_armer] = i.obj_id;        //next using this data,configure enemy`s Id
						this->dataset.armour[index].armour_confidence[number_of_armer] = i.prob;
						this->dataset.armour[index].number_of_armer++;
                    }
                }
#ifdef VISION_DATACHECK
                std::cout << "(armour_assign) Armour " << index << " founded Number of" << index << " :" << this->dataset.armour[index].number_of_armer << std::endl;
#endif
            }
        }
    }
}
float data_control::VisionDataset_avoid_zero(short x, short y) {
	//to use this function, x andy must be larger then 3 and smaler than Max-3
	float Depth = 0;
	float tem_Depth = 0;
	short i = 0;
	short j = 0;
	short count = 0;
	for (i = x; i < x + 3; i++) {
		for (j = y; j < y + 3; j++) {
			tem_Depth = this->dataset.depth_img.at<double>((i - 1), (j - 1));  //opencv_depth frame 
			if (tem_Depth > 0) {
				count++;
				Depth = Depth + tem_Depth;
			}
		}
	}
	if (count > 0) {
		Depth = Depth / count;

#ifdef DEBUG
		std::cout << "(VisionDataset_avoid_zero) get_distance_is succeed " << std::endl;
#endif


		return Depth;
	}
	else {
#ifdef DEBUG
		std::cout << "(VisionDataset_avoid_zero) distance is zero" << std::endl;
#endif
		return 0;
	}
}
float data_control::linial_align(short RGB_X, short RGB_Y) {
	// based on 3m > 6 pixel moved and it is for 640*480
	short fake_depth_x = (RGB_X * 0.63125 + 112);

	short real_depth_y = (RGB_Y * 0.63125 + 88.5);
	float fake_distance = this->VisionDataset_avoid_zero(fake_depth_x, real_depth_y);
	float distance = 0;


	if (fake_distance > 0) {
		short move_pixel = (17.72 / fake_distance);
		short real_depth_x = (RGB_X * 0.63125 + 118 - move_pixel);
		fake_distance = this->VisionDataset_avoid_zero(real_depth_x, real_depth_y);
	}

	if (fake_distance > 0) {
		short move_pixel = (17.72 / fake_distance);
		short real_depth_x = (RGB_X * 0.63125 + 118 - move_pixel);
		distance = this->VisionDataset_avoid_zero(real_depth_x, real_depth_y);
	}

#ifdef DEBUG
	if (distance == 0) {
		std::cout << "(linial_align)_fail to get distance / distance = 0" << std::endl;
	}
#endif //!DEBUG
	return distance;
}
/***************************************************************************************************************/
void send_control::Send_robot_info_clear(Send_robot_info& robot) {

	robot.type_of_robot = 0; // 0 > no data 1 = aliance , 2= enemy , 3 = dead , 4= unknown
	robot.angle_hori = 0;   // based on center line left is minus, righet is pluse
	robot.angle_verti = 0;   // based on center line upper is plus lower is minus  
	robot.Pixel_X = 0;  //center_X
	robot.Pixel_Y = 0;  //center_Y
	robot.Pixel_width = 0;     //pixel coordinate`s width 
	robot.Pixel_height = 0;    //pixel coordinate`s height
	robot.distance = 0;  //it is based on meter 
	robot.assigned_number = 0;  //dominent number of armour
	robot.numbers_of_armour = 0; // total detected number of armour
	for (int i = 0; i < 6; i++) {
		robot.assinged_armour_number[i] = 0;  //all armour data of robot
		robot.prob_of_armour[i] = 0; // probability of each armour
	}
	robot.prob_of_robot = 0;

}
void send_control::to_black_board_clear() {
	this->to_black_board.number_of_detection = 0;
	for (int i = 0; i < 6; i++) {
		this->Send_robot_info_clear(this->to_black_board.send_robot_info[i]);
	}
}
void send_control::to_gimbal_clear() {
	this->to_gimbal.infochecker = 0;  //if 0: no data, 1: target, 2: area of interest
	this->to_gimbal.Pixel_X = 0;
	this->to_gimbal.Pixel_Y = 0;
	this->to_gimbal.distance = 0;
}
void send_control::send_data_clear() {
	this->to_black_board_clear();
	this->to_gimbal_clear();

#ifdef DEBUG
	std::cout << " (send_control::send_data_clear) send_data_clear is worked " << std::endl;
#endif //!DEBUG
}
void send_control::angle_maker(short& hori, short& verti, data_control& CT_data, int i) {
	//realsense data (Dapth) hori angle 65.2 verti angle 58 diagonal 94 error +-3 >> during experiment, we find that angle of verti is 54.5
//RGB viewing angle horiangle 69.4 veri angle 42.5 diagonal 77 erroe +-3
// but we need only RGB angle 
// 60degree * pi/180 = radian. 
// 60degree = radian*180/pi
// minus is left and bottom 
// plus is right and top 
// if data type is short is 4301 means 43.01 degree  
	if (CT_data.dataset.Center_X[i] == 0 || CT_data.dataset.Center_Y[i] == 0 || CT_data.dataset.width[i] == 0 || CT_data.dataset.height[i] == 0) {
		hori = 0;
		verti = 0;
		return;
	}

	short Width = 640 * 0.5;  //640
	short Height = 480 * 0.5; //480  input half of piexl data
	double a = 54.5*0.5 * 3.14159 / 180;
	double hehe;
	double x;

	if (CT_data.dataset.Center_X[i] < (Width)) {
		hehe = (Width - CT_data.dataset.Center_X[i])*tan(a) / Width;
		x = atan(hehe);
		hori = (-1 * (x * 100)) * 180 / 3.14159;  //minus is left

	}
	else if (CT_data.dataset.Center_X[i] == Width) {
		hori = 0;
	}
	else {
		hehe = (CT_data.dataset.Center_X[i] - Width)*tan(a) / Width;
		x = atan(hehe);
		hori = 1 * (x * 100) * 180 / 3.14159;  //pluse is right 
	}

	if (CT_data.dataset.Center_Y[i] < (Height)) {
		hehe = (Height - CT_data.dataset.Center_Y[i])*tan(a * 0.75) / Height;
		x = atan(hehe);
		verti = 1 * (x * 100) * 180 / 3.14159;

	}
	else if (CT_data.dataset.Center_Y[i] == (Height)) {
		verti = 0;
	}
	else {
		hehe = (CT_data.dataset.Center_Y[i] - Height)*tan(a * 0.75) / Height;
		x = atan(hehe);
		verti = -1 * (x * 100) * 180 / 3.14159;
	}


}
void send_control::send_black_board_maker(data_control& CT_data) {
	this->to_black_board.number_of_detection = CT_data.dataset.number_of_detection;

	for (int i = 0; i < 6; i++) {
		this->to_black_board.send_robot_info[i].type_of_robot = CT_data.dataset.robot_id[i];
		this->angle_maker(this->to_black_board.send_robot_info[i].angle_hori, this->to_black_board.send_robot_info[i].angle_verti, CT_data ,i);
		this->to_black_board.send_robot_info[i].Pixel_X = CT_data.dataset.Center_X[i];
		this->to_black_board.send_robot_info[i].Pixel_Y = CT_data.dataset.Center_Y[i];
		this->to_black_board.send_robot_info[i].Pixel_width = CT_data.dataset.width[i];
		this->to_black_board.send_robot_info[i].Pixel_height = CT_data.dataset.height[i];
		this->to_black_board.send_robot_info[i].distance = CT_data.dataset.distance[i];
		this->to_black_board.send_robot_info[i].assigned_number = CT_data.dataset.armour[i].dominant_armour;

		this->to_black_board.send_robot_info[i].numbers_of_armour = CT_data.dataset.armour[i].number_of_armer ;
		this->to_black_board.send_robot_info[i].prob_of_robot = CT_data.dataset.prob[i];

		for (int j = 0; j < 6; j++) {
			this->to_black_board.send_robot_info[i].assinged_armour_number[j] = CT_data.dataset.armour[i].armour_type[j];
			this->to_black_board.send_robot_info[i].prob_of_armour[j] = CT_data.dataset.armour[i].armour_confidence[j];
		}
	}
} 
void send_control::send_gimbal_maker(data_control& CT_data) {
	// operate only there are robot.
	if (CT_data.dataset.number_of_detection > 0) {
		send_target_info bast_target = this->find_target(CT_data);
		this->to_gimbal = bast_target;
	}
}
void send_control::send_data_maker(data_control& CT_data) {
	/*before running clear the all send data*/
	this->to_black_board_clear();
	this->to_gimbal_clear();

	/*making data of enemy*/
	this->send_black_board_maker(CT_data);
	this->send_gimbal_maker(CT_data);

}
send_target_info send_control::find_target(data_control& CT_data) {
	int count_enemy = 0;
	float check_robot_prob = 0;
	int target_enemy = 6;
	send_target_info target;
	for (int i = 0; i < 6; i++) {
		if (CT_data.dataset.robot_id[i] == enemy_id) {
			count_enemy++;
			if (check_robot_prob < CT_data.dataset.prob[i]) {
				check_robot_prob = CT_data.dataset.prob[i];
				target_enemy = i;
			}
		}
	}
	if (target_enemy < 6) {
		if (CT_data.dataset.armour[target_enemy].number_of_armer > 0) {
			target.infochecker = 1;
			target.Pixel_X = CT_data.dataset.armour[target_enemy].Center_x[0];
			target.Pixel_Y = CT_data.dataset.armour[target_enemy].Center_y[0];
			target.distance = CT_data.linial_align(target.Pixel_X, target.Pixel_Y);
		}
		else
		{
			target.infochecker = 2; // can`t find armour
			target.Pixel_X = CT_data.dataset.Center_X[target_enemy];
			target.Pixel_Y = CT_data.dataset.Center_Y[target_enemy];
			target.distance = CT_data.dataset.distance[target_enemy];
		}
	}

#ifdef DEBUG
	std::cout << " (send_control::find_target) find_target is worked " << std::endl;
#endif //!DEBUG
#ifdef VISION_DATACHECK
    std::cout << " (target)  target.info:" << target.infochecker << "Pixel_X:"<< target.Pixel_X <<"Pixel_Y:"<<target.Pixel_Y<<"distace:"<<target.distance <<std::endl;
#endif //!VISION_DATACHECK
	return target;
}
/***************************************************************************************************************/
#endif // !DATA_CONTROL_HPP





