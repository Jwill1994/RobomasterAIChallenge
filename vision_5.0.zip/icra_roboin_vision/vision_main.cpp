#define BASIC_FUNCTION  //this is for basic function (using ROS)

#define DISPLAY  // control opencv_ imshow function with object_Detection
#ifndef DISPLAY
    #define DISPLAY_ONLY_CAMERA  //Show only Camera image
#endif

// #define DEBUG  //show what function start and worked

//#ifdef BASIC_FUNCTION
//#define VIRTUAL  // for mechine learning code with object detection  (must run with BASIC_FUNCTION)
//#endif

#define VISION_DATACHECK //show visoin output data such as number of detection
//#define ZIMBAL_DATACHECK //show zimbal`s output data such as angle


//#define MAKEING_IMG //this fucntion is making a img
//#define ADD_DEEPLEARNING  //makeing image while using object detection


#include "src/all.hpp"
#include <time.h>
int main(int argc, char **argv) {

	ros::init(argc, argv, "vision_node");
	ros::NodeHandle nh;  //ros node init


	/*
	 *
	 * /home/nvidia/weights/420_224_model_with_420_224_image/yolov3-tiny_420_224.backup
	 *
	 *
	 */
	/*Original Network*/
//	std::string  names_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolo3.names";
//	std::string  cfg_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolov3.cfg";
//	std::string  weights_file = "/home/nvidia/CLionProjects/vision_dev/yolo/config_backup/yolov3-tiny.backup";
	
	/*Yolo v3-tiny 7classes*/
//	std::string  names_file = "/home/nvidia/weights/420_224_model_with_420_224_image/yolo3.names";
//	std::string  cfg_file = "/home/nvidia/weights/420_224_model_with_420_224_image/yolov3.cfg";
//	std::string  weights_file = "/home/nvidia/weights/420_224_model_with_420_224_image/yolov3-tiny_420_224.backup";

    	/*Yolo v3-tiny 3classes*/
	std::string  names_file = "/home/nvidia/weights/yolov3-tiny_3c/obj.names";
	std::string  cfg_file = "/home/nvidia/weights/yolov3-tiny_3c/yolov3-tiny_420_224.cfg";
	std::string  weights_file = "/home/nvidia/weights/yolov3-tiny_3c/yolov3-tiny_420_224.backup";

	/*Yolo v2 3classes*/
//	std::string names_file = "/home/nvidia/weights/yolov2/obj.names";
//	std::string cfg_file="/home/nvidia/weights/yolov2/yolov2_test.cfg";
//	std::string weights_file= "/home/nvidia/weights/yolov2/yolov2.backup";

	darknet::Detector detector_yolo(cfg_file, weights_file); //yolo detector

	data_control CT_data; //define basic data class
	vision_camera camera(nh); //camera class initialize
	vision_detector detector(detector_yolo); //object detector class setup

	send_control send_control; //send data to black board and gimblal
	GimbalControl gimbalControl(nh);

	vision_ros vision_ros(nh);

	float start;
	float end;
	float FPS;
	while (true) {
		start=std::clock();
		camera.vision_camera_run(CT_data);  //get camera_color_image
                detector.vision_detector_run(camera, CT_data, detector_yolo);  //run object detector and assign output data
                camera.making_img(CT_data); //this is for makeing img for labeling, and if #MAKEING_IMG is not define than, nothing happen
                send_control.send_data_maker(CT_data); //makeing send data.
                gimbalControl.run(send_control.to_gimbal);
                //robotsInfo.pubEnemyInfo(send_control.to_black_board);
		end=std::clock();
		FPS=1000000/(end-start);	
//		std::cout << std::to_string(FPS) << std::endl;
		if(cv::waitKey(1)==113){
		break;
		}
	}

}

