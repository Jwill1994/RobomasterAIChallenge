#!/bin/bash
bash -c "source /home/dji/.bashrc && roslaunch roborts_bringup roborts.launch"
