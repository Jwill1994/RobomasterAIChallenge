#ifndef ALL_HPP
#define ALL_HPP

#include "pch.hpp"
#include "Data_control.hpp"
#include "yolo_class.hpp"
#include "object_detection.hpp"
#include "Vision_ros.hpp"
#include "GimbalControl.hpp"
#include "remote.hpp"
#include <time.h>
#endif // !ALL_HPP

